<footer class="footer text-center"> 2021 © Ample Admin brought to you by <a
    href="https://www.wrappixel.com/">wrappixel.com</a>
</footer>