<div class="mian-content">
    <ul>
        <li>Loại chính sách: <b>{{ $doituong[0]->dt_ten }}</b></li>
        <li>Hình thức: <b>{{ $doituong[0]->dt_hinhthuc }}</b></li>
        <li>Mô tả: <b>{{ $doituong[0]->dt_mota }}</b></li>
    </ul>
</div>