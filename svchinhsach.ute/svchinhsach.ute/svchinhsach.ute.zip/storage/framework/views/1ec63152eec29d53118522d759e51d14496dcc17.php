

<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Quản lý CTSV</h4>
                    </div>
                    
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12" style="text-align: right; margin-bottom: 15px;">
                        <a style="color: white" href="<?php echo e(route('admin.ctsv.create')); ?>" class="btn btn-info"> Thêm mới <i class="fas fa-plus"></i></a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <?php if(Session::has('status')): ?>
                        <div class="alert alert-success"><?php echo e(Session::get('status')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <?php if(Session::has('err')): ?>
                        <div class="alert alert-danger"><?php echo e(Session::get('err')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-12">
                        <div class="white-box">
                            <h3 class="box-title">Danh sách CTSV</h3>
                            <p>Mật khẩu mặc định: 12345678</p>
                            <div class="table-responsive">
                                <table class="table text-nowrap">
                                    <thead>
                                        <tr>
                                            
                                            <th class="border-top-0">Họ tên</th>
                                            <th class="border-top-0">Email</th>
                                            <th class="border-top-0">Điện thoại</th>
                                            <th class="border-top-0">Địa chỉ</th>
                                            <th class="border-top-0">Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php $__currentLoopData = $ctsv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->ctsv_ten); ?></td>
                                                <td><?php echo e($item->ctsv_email); ?></td>
                                                <td><?php echo e($item->ctsv_sdt); ?></td>
                                                <td><?php echo e($item->ctsv_diachi); ?></td>
                                                
                                                

                                                <td>
                                                    <a href="<?php echo e(route('admin.ctsv.edit', $item->id)); ?>" class="btn btn-warning">
                                                        <i class="far fa-edit"></i>
                                                    </a>

                                                    <a onclick="return confirm('Are you sure you want to delete this item?');" href="<?php echo e(route('admin.ctsv.delete', $item->id)); ?>" class="btn btn-danger">
                                                        <i class="far fa-trash-alt"></i>
                                                    </a>
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                 
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\Modules/Admin\Resources/views/ctsv/index.blade.php ENDPATH**/ ?>