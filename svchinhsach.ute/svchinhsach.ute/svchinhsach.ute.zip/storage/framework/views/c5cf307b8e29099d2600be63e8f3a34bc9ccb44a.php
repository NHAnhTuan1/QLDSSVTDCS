

<?php $__env->startSection('content'); ?>
    <section class="login" style="padding-top: 50px; padding-bottom: 160px">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="text-center">Đăng nhập CTSV</h4>
                </div>
            </div>
            <div class="row" style="justify-content: center;">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-12">
                            <?php if(Session::has('err')): ?>
                                <div class="alert alert-danger"><?php echo e(Session::get('err')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <form action="<?php echo e(route('ctsv.post.login')); ?>" method="POST">
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" placeholder="Nhập email" id="email" name="email" value="<?php echo e(old('email')); ?>">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="pwd">Mật khẩu:</label>
                            <input type="password" class="form-control" placeholder="Nhập mật khẩu" id="pwd" name="password">
                            
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Đăng nhập</button>

                        <a class="d-block mt-3" href="">Quên mật khẩu?</a>
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/ctsv/login.blade.php ENDPATH**/ ?>