
<?php $__env->startSection('content'); ?>
<section class="list mt-5" style="margin-bottom: 150px">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4 class="text-center">Thay đổi mật khẩu</h4>
            </div>
        </div>
        <form action="<?php echo e(route('sv.post.changePass')); ?>" method="POST" >
            <div class="row" style="justify-content: center">
                <div class="col-md-6">
                    <?php if(Session::has('err')): ?>
                        <div class="alert alert-danger"><?php echo e(Session::get('err')); ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row" style="justify-content: center">
                <div class="col-md-6">
                    <?php if(count($errors)>0): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($err); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row" style="justify-content: center">
                
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="email">Mật khẩu cũ:</label>
                        <input name="password_old"  type="password" class="form-control" id="email" value="">
                    </div>
                    <div class="form-group">
                        <label for="pwd">Mật khẩu mới:</label>
                        <input name="password_new"  type="password" class="form-control" id="pwd" value="">
                    </div>
                    <div class="form-group">
                        <label for="pwd">Xác nhận mật khẩu mới:</label>
                        <input name="password_new_confirmation" type="password" class="form-control" id="pwd" value="">
                    </div>
                    <button type="submit" class="btn btn-primary">Xác nhận</button>
                </div>
            </div>
            <?php echo csrf_field(); ?>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/sinhvien/changePass.blade.php ENDPATH**/ ?>