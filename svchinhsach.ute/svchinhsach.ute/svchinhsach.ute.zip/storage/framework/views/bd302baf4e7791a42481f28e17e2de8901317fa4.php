

<?php $__env->startSection('content'); ?>
    <section class="kq" style="min-height: 500px">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4>Kết quả tìm kiếm cho từ khóa: <?php echo e($tukhoa); ?></h4>
                </div>
            </div>
            <div class="row">
            
            <?php if($data->count() > 0): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="card" >
                        <img style="padding: 20px" class="card-img-top" src="<?php echo e(URL::asset('public/fe/images/avt1.png')); ?>" alt="Card image">
                        <div class="card-body">
                            <h4 class="card-title" style="font-size: 20px;font-weight: 600;"><?php echo e($d->dt_ten); ?></h4>
                            <a href="<?php echo e(route('get.detail.dt', [Str::slug($d->dt_ten),$d->id])); ?>" class="btn btn-primary">Xem chi tiết</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-md-12">
                    <span class="text-danger">Không tìm thấy kết quả!</span>
                </div>
            <?php endif; ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/timkiem/ketquachinhsach.blade.php ENDPATH**/ ?>