

<?php $__env->startSection('content'); ?>
    

    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h3>Tên đối tượng: <?php echo e($detail[0]->dt_ten); ?></h3>
                    <h5>Hình thức: <?php echo e($detail[0]->dt_hinhthuc); ?> </h5>
                    
                        <?php echo e($detail[0]->dt_mota); ?>


                    
                    <img src="http://placehold.it/700x400" alt="">
                </div>
                <div class="col-md-12 mt-3 mb-3">
                    <a href="<?php echo e(route('sv.get.dangki', $detail[0]->id)); ?>" class="btn btn-success">Đăng ký</a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/doituong/detail.blade.php ENDPATH**/ ?>