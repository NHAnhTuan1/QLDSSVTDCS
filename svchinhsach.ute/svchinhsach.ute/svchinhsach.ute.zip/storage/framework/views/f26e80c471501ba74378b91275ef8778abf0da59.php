<div class="mian-content">
    <ul>
        <li>Loại chính sách: <b><?php echo e($doituong[0]->dt_ten); ?></b></li>
        <li>Hình thức: <b><?php echo e($doituong[0]->dt_hinhthuc); ?></b></li>
        <li>Mô tả: <b><?php echo e($doituong[0]->dt_mota); ?></b></li>
    </ul>
</div><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\Modules/Admin\Resources/views/ajax/detailDT.blade.php ENDPATH**/ ?>