

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8">

            <!--Form tìm kiếm-->
            <form class="form-inline"  method="GET">
                <input type="text" class="form-control" placeholder="Tên" name="ten" value="<?php echo e(\Request::get('ten')); ?>"> 

                <span>&nbsp;</span>

                <select class="form-control" name="hk">
                    <option value="">-- Học kỳ --</option>

                    <?php $__currentLoopData = $hocki; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e((\Request::get('hk') == $hk->id)?'selected':''); ?> value="<?php echo e($hk->id); ?>"><?php echo e($hk->hk_ma); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
                <span>&nbsp;</span>
                <button type="submit" class="btn btn-info">Tìm</button>
            </form>


        </div>
        <div class="col-md-4">
            <a href="<?php echo e(route('ctsv.view.excel')); ?>" class="btn btn-warning mb-1" style="float: right"><i class="far fa-file-excel">&nbsp</i>Xuất file Excel</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card spur-card">
                <div class="card-header">
                    <div class="spur-card-icon">
                        <i class="fas fa-table"></i>
                    </div>
                    <div class="spur-card-title">Danh sách sinh viên đăng ký diện chính sách</div>
                </div>
                <div class="card-body ">
                    <table class="table table-in-card">
                        <thead>
                            <tr>
                                
                                <th scope="col">Họ và tên</th>
                                <th scope="col">Lớp</th>
                                <th scope="col">Đối tượng</th>
                                <th scope="col">Mã học kỳ</th>
                                <th scope="col">Tình trạng</th>
                                <th scope="col">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                           
                        <?php $__currentLoopData = $cs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                
                                <td><?php echo e($c->sv_ten); ?></td>
                                <td><?php echo e($c->l_ten); ?></td>
                                <td><?php echo e($c->dt_ten); ?></td>
                                <td><?php echo e($c->hk_ma); ?></td>
                                <td>

                                    <?php if( $c->tinhtrang == 0 ): ?>
                                        <span class="badge badge-secondary">Chờ duyệt</span>
                                    <?php endif; ?>
                                    <?php if( $c->tinhtrang == 1 ): ?>
                                        <span class="badge badge-success">Chấp nhận</span> 
                                    <?php endif; ?>
                                    <?php if( $c->tinhtrang == 2 ): ?>
                                        <span class="badge badge-danger">Không chấp nhận</span>
                                    <?php endif; ?>
                                    
                                </td>
                                <td>
                                    <a href="<?php echo e(route('ctsv.view.chitiet', $c->chinhsach_id)); ?>" data-toggle="tooltip" title="Duyệt" class="btn btn-info"><i class="fas fa-arrow-alt-circle-right"></i></a>

                                    <button data-href="<?php echo e(route('ajax.detail.sv.dangki', $c->chinhsach_id)); ?>" class="btn btn-success mb-1 chitietDK">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                            
                        </tbody>
                    </table>
                    <?php echo e($cs->links()); ?>

                </div>
            </div>
        </div>
        
    </div>
    <!-- The Modal -->
    <div class="modal fade" id="chitietSVModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h5 class="modal-title">Chi tiết đăng ký: </h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    
                </div>
                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('.chitietDK').click(function (e) { 
            e.preventDefault();
            var url = $(this).attr('data-href');
            $.post(url, function(data){


                $('#chitietSVModal .modal-body').html(data);
                $('#chitietSVModal').modal();
            });


            // $('#chitietSVModal .modal-body').html();
            // $('#chitietSVModal').modal();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ctsv.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/ctsv/choduyet.blade.php ENDPATH**/ ?>