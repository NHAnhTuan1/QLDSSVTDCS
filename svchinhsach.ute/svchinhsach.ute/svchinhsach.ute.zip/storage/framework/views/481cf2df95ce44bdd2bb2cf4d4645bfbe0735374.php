

<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Sửa nhân viên</h4>
                    </div>
                    
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <?php if(Session::has('status')): ?>
                        <div class="alert alert-success"><?php echo e(Session::get('status')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <?php if(Session::has('err')): ?>
                        <div class="alert alert-danger"><?php echo e(Session::get('err')); ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-12">
                        <?php if(count($errors)>0): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($err); ?> <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-12">
                        <div class="card"> 
                            <div class="card-body">
                                <form class="form-horizontal form-material" action="<?php echo e(route('admin.ctsv.update')); ?>" method="POST">

                                    

                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">Họ tên</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input type="text" class="form-control p-0 border-0" name="ctsv_ten"   required value="<?php echo e($ctsv[0]->ctsv_ten); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">Email</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input type="email" class="form-control p-0 border-0" name="ctsv_email"  required value="<?php echo e($ctsv[0]->ctsv_email); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">Số điện thoại</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input type="text" class="form-control p-0 border-0" name="ctsv_sdt"   required value="<?php echo e($ctsv[0]->ctsv_sdt); ?>"> 
                                        </div>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">Địa chỉ</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input type="text" class="form-control p-0 border-0" name="ctsv_diachi"  value="<?php echo e($ctsv[0]->ctsv_diachi); ?>"> 
                                        </div>
                                    </div>
                                   
                                    
                                    <div class="form-group mb-4">
                                        <div class="col-sm-12">
                                            <button type="submit" class="btn btn-success">Cập nhật</button>
                                        </div>
                                    </div>
                                    <input type="hidden" name="id" id="" value="<?php echo e($ctsv[0]->id); ?>">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\Modules/Admin\Resources/views/ctsv/edit.blade.php ENDPATH**/ ?>