

<?php $__env->startSection('content'); ?>
    <section class="list mt-5 mb-5" style="min-height: 400px">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="text-center">Danh sách đã đăng ký</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">

                    <table class="table table-bordered" style="margin-bottom: 90px">
                        <thead>
                            <tr>
                                <th >#</th>
                                <th >Họ và tên</th>
                                <th >Lớp</th>
                                <th >Đối tượng</th>
                                <th >Ngày sinh</th>
                                <th >Trạng thái</th>
                                <th >Học kỳ</th>
                                <th >Ngày đăng ký</th>
                                <th >Ngày duyệt</th>
                                <th >Người duyệt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $stt=0;
                            ?>

                        <?php if($list->count() >0): ?>
                            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php
                                    $stt++;
                                ?>
                                <tr>
                                    <td><?php echo e($stt); ?></td>
                                    <td><?php echo e($l->sv_ten); ?></td>
                                    <td><?php echo e($l->l_ten); ?></td>
                                    <td><?php echo e($l->dt_ten); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($l->sv_ngaysinh))); ?></td>
                                    <td>
                                        <?php if($l->tinhtrang == 0): ?>
                                            <span class="badge badge-secondary">Chờ duyệt</span>
                                        <?php endif; ?>
                                        <?php if($l->tinhtrang == 1): ?>
                                            <span class="badge badge-success">Chấp nhận</span>
                                        <?php endif; ?>
                                        <?php if($l->tinhtrang == 2): ?>
                                            <span class="badge badge-warning">Đã hủy</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($l->hk_ma); ?></td>
                                    <td><?php echo e($l->ngaydangki); ?></td>
                                    <td>
                                        <?php if($l->ngayduyet == null): ?>
                                            Chưa duyệt
                                        <?php else: ?>
                                            <?php echo e($l->ngayduyet); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($l->ngayduyet == null): ?>
                                        
                                        <?php else: ?>
                                            CTSV
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <span class="text-warning">Bạn chưa đăng ký loại chính sách nào.</span>
                        <?php endif; ?>
                            
                        </tbody>
                    </table>

                </div>
            </div>

            
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/sinhvien/dsDangKi.blade.php ENDPATH**/ ?>