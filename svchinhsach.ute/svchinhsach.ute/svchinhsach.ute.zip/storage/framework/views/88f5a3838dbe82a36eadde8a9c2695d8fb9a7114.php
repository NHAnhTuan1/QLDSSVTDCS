

<?php $__env->startSection('content'); ?>

    

    <div class="row">
        <div class="col-lg-12">
            <div class="card spur-card">
                <div class="card-header">
                    <div class="spur-card-icon">
                        <i class="fas fa-table"></i>
                    </div>
                    <div class="spur-card-title">Danh sách sinh viên thuộc diện chính sách</div>
                </div>
                <div class="card-body ">
                    <table class="table table-in-card" id="table2excel">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Họ và tên</th>
                                <th scope="col">Lớp</th>
                                <th scope="col">Đối tượng</th>
                                <th scope="col">Ngày sinh</th>
                                <th scope="col">Hình thức</th>
                                <th scope="col">Mã học kỳ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $stt=1;
                            ?>
                        <?php $__currentLoopData = $excel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($stt++); ?></th>
                                <td><?php echo e($ex->sv_ten); ?></td>
                                <td><?php echo e($ex->l_ten); ?></td>
                                <td><?php echo e($ex->dt_ten); ?></td>
                                <td><?php echo e(date('d/m/Y', strtotime($ex->sv_ngaysinh))); ?></td>
                                <td><?php echo e($ex->dt_hinhthuc); ?></td>
                                <td><?php echo e($ex->hk_ma); ?></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <button type="button" class="btn btn-secondary mb-1" id="xuat">Tải xuống(Excel)</button>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('ctsv.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/ctsv/excel.blade.php ENDPATH**/ ?>