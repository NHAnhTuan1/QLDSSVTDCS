

<?php $__env->startSection('content'); ?>

    <section class="timkiem" style="min-height: 500px">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="card spur-card" style="min-height: 375px">
                        <div class="card-header">
                           
                            <div class="spur-card-title"> Tìm kiếm </div>
                        </div>
                        <div class="card-body ">
                            
                                
                                <div class="form-group">
                                    <label for="inputAddress2">Nhập từ khóa ở đây</label>
                                    <input type="text" class="form-control" placeholder="Nhập từ khóa muốn tìm kiếm.." name="q" required id="keyword">
                                </div>

                                <button data-href="<?php echo e(route('ajax.search')); ?>" type="button" id="searchDT" class="btn btn-primary">Tìm kiếm</button>
                                <?php echo csrf_field(); ?>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="card spur-card" style="min-height: 375px">
                        <div class="card-header">
                            <div class="spur-card-title"> Kết quả tìm kiếm <b id="total"></b></div>
                        </div>
                        <div class="card-body">
                            <div class="row" id="resultSearch">
                                <!--Phun kết quả từ ajax ra đây-->

                                

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $("#searchDT").click(function (e) { 
            e.preventDefault();
            var keyword = $('#keyword').val();
            var url = $(this).attr('data-href');
            if (keyword) {
                
                $.post(url, {keyword: keyword}, function(data){
                    if (data.total >0) {
                        $('#total').html(data.total);
                        $('#resultSearch').html(data.html);
                    }else{

                        alert('Không tìm thấy dữ liệu');
                        $('#total').html(0);
                        $('#resultSearch').html(null);
                    }
                });
            }
            
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/timkiem/index.blade.php ENDPATH**/ ?>