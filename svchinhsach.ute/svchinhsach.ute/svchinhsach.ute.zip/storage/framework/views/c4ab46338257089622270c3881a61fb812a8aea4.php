<div class="main-content">
    <div class="row">
        <div class="col-md-6">
            <ul>
                <li>Họ và tên: <b><?php echo e($chitiet[0]->sv_ten); ?></b></li>
                <li>Lớp: <b><?php echo e($chitiet[0]->l_ten); ?></b></li>
                <li>Khoa: <b><?php echo e($chitiet[0]->k_ten); ?></b></li>
                <li>Địa chỉ: <b><?php echo e($chitiet[0]->sv_diachi); ?></b></li>
                <li>Năm sinh: <b><?php echo e($chitiet[0]->sv_ngaysinh); ?></b></li>
                <li>Ngày đăng ký: <b><?php echo e($chitiet[0]->created_at); ?></b></li>
            </ul>
        </div>
        <div class="col-md-6">
            <ul>
                <li>Chứng minh nhân dân: <b><?php echo e($chitiet[0]->sv_cmnd); ?></b></li>
                <li>Số điện thoại: <b><?php echo e($chitiet[0]->sv_sdt); ?></b></li>
                <li>Email: <b><?php echo e($chitiet[0]->sv_email); ?></b></li>
                <li>Loại chính sách: <b><?php echo e($chitiet[0]->dt_ten); ?></b></li>
                <li>Mã học kì: <b><?php echo e($chitiet[0]->hk_ma); ?></b></li>
                <li>Ngày duyệt: <b><?php echo e($chitiet[0]->updated_at); ?></b></li>
                
            </ul>
        </div>
        <div class="col-md-12"><hr></div>
        <div class="col-md-12">
            <ul>
                <li>Tình trạng:
                    <?php if($chitiet[0]->tinhtrang == 0): ?>
                        <b class="text-warning">Chưa duyệt</b> 
                    <?php endif; ?>
                    <?php if($chitiet[0]->tinhtrang == 1): ?>
                        <b class="text-success">Chấp nhận</b> 
                    <?php endif; ?>
                    <?php if($chitiet[0]->tinhtrang == 2): ?>
                        <b class="text-danger">Không chấp nhận</b>
                    <?php endif; ?> 
                </li>
            </ul>
            
        </div>
        <div class="col-md-12">
            
            <ul>
                <b>Các minh chứng:</b>
                <?php $__currentLoopData = $minhchung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a target="_blank" href="<?php echo e($mc->mc_file); ?>">Minh chứng 1</a> 
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </ul>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/ctsv/ajax/detailDangKi.blade.php ENDPATH**/ ?>