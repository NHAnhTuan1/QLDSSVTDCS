

<?php $__env->startSection('content'); ?>
    <section class="list mt-5 mb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="text-center">Đăng ký diện chính sách</h4>
                </div>
                
            </div>

            <form action="<?php echo e(route('sv.post.dangki')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6">
                    
                    <div class="form-group">
                        <label for="email">Họ và tên:</label>
                        <input readonly="" type="email" class="form-control" id="email" value="<?php echo e($sinhvien[0]->sv_ten); ?>" name="ten">
                    </div>
                    <div class="form-group">
                        <label for="pwd">Lớp:</label>
                        <input readonly="" type="text" class="form-control" id="pwd" value="<?php echo e($sinhvien[0]->l_ten); ?>" name="lop">
                    </div>
                    
                    
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="pwd">Khoa:</label>
                        <input readonly="" type="text" class="form-control" id="pwd" value="<?php echo e($sinhvien[0]->k_ten); ?>" name="khoa">
                    </div>

                    <div class="form-group">
                        <label for="pwd">Địa chỉ:</label>
                        <input readonly="" type="text" class="form-control" id="pwd" value="<?php echo e($sinhvien[0]->sv_diachi); ?>" name="diachi">
                    </div>
                    
                </div>

                <div class="col-md-12">

                    <label for="sel1">Chọn học kỳ:</label>
                        <select class="form-control" id="sel1" style="margin-bottom: 1rem" name="hocki">

                        <?php $__currentLoopData = $hocki; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($hk->id); ?>"><?php echo e($hk->hk_ma); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                    <label for="sel1">Chọn đối tượng</label>
                    <select class="form-control" id="sel1" style="margin-bottom: 1rem" name="doituong">

                    
                        <option value="<?php echo e($doituong[0]->id); ?>"><?php echo e($doituong[0]->dt_ten); ?></option>
                    

                    </select>
                    

                    
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label for="pwd">Ảnh minh chứng(có thể chọn nhiều ảnh):</label>
                        <input name="minhchung[]" type="file" multiple="multiple" class="form-control" id="pwd" required>
                        <?php $__errorArgs = ['minhchung[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-12">
                    <button type="submit" class="btn btn-success">Xác nhận đăng ký</button>
                </div>
            </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/sinhvien/dangki.blade.php ENDPATH**/ ?>