


<?php $__env->startSection('chart'); ?>
    <script  src="https://www.gstatic.com/charts/loader.js"></script>
    <script >
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

            var data = google.visualization.arrayToDataTable([

            ['Task', 'Hours per Day'],
                <?php echo $chartData; ?>

            
            ]);

            var options = {
            title: 'Thống kê theo khoa'
            };
            var chart = new google.visualization.PieChart(document.getElementById('piechart'));
            chart.draw(data, options);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="page-breadcrumb bg-white">
        <div class="row align-items-center">
            <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                <h4 class="page-title">Quản lý thống kê</h4>
            </div>
            
        </div>
        <!-- /.col-lg-12 -->
    </div>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-10">
                <h2>Thống kê</h2>
                <div id="piechart" style="width: 900px; height: 500px;"></div>
            </div>
            <div class="col-md-10">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Mã Khoa</th>
                            <th>Tên khoa</th>
                            <th>Số lượng</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $thongkekhoa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->k_ma); ?></td>
                                <td><?php echo e($item->k_ten); ?></td>
                                <td><?php echo e($item->soluong); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </tbody>
                </table>
            </div>
        </div>    
    </div> 
            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\Modules/Admin\Resources/views/thongke/khoa.blade.php ENDPATH**/ ?>