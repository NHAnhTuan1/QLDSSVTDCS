

<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card spur-card">

                <div class="card-header">
                    <div class="spur-card-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <div class="spur-card-title"> Chi tiết đăng ký của sinh viên: <?php echo e($chitiet[0]->sv_ten); ?></div>
                </div>

                <div class="card-body ">
                    <form action="<?php echo e(route('post.sv.chinhsach')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Họ và tên: </label>
                            <input readonly type="text" class="form-control" id="exampleFormControlInput1" value="<?php echo e($chitiet[0]->sv_ten); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Lớp: </label>
                            <input readonly type="text" class="form-control" id="exampleFormControlInput1" value="<?php echo e($chitiet[0]->l_ten); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Khoa: </label>
                            <input readonly type="text" class="form-control" id="exampleFormControlInput1" value="<?php echo e($chitiet[0]->k_ten); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Địa chỉ: </label>
                            <input readonly type="text" class="form-control" id="exampleFormControlInput1" value="<?php echo e($chitiet[0]->sv_diachi); ?>">
                        </div>
            
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Năm sinh: </label>
                            <input readonly type="date" class="form-control" id="exampleFormControlInput1" value="<?php echo e($chitiet[0]->sv_ngaysinh); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">CMND: </label>
                            <input readonly type="text" class="form-control" id="exampleFormControlInput1" value=" <?php echo e($chitiet[0]->sv_cmnd); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Số điện thoại: </label>
                            <input readonly type="text" class="form-control" id="exampleFormControlInput1" value=" <?php echo e($chitiet[0]->sv_sdt); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Email: </label>
                            <input readonly type="text" class="form-control" id="exampleFormControlInput1" value=" <?php echo e($chitiet[0]->sv_email); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Tên đối tượng: </label>
                            <input readonly type="text" class="form-control" id="exampleFormControlInput1" value=" <?php echo e($chitiet[0]->dt_ten); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Học kỳ: </label>
                            <input readonly type="text" class="form-control" id="exampleFormControlInput1" value="<?php echo e($chitiet[0]->hk_ma); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Các ảnh minh chứng:(Click vào để xem) </label>
                            <ul>

                            <?php $__currentLoopData = $minhchung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a target="_blank" href="<?php echo e($mc->mc_file); ?>"><?php echo e($mc->mc_file); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                            </ul>
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleFormControlSelect1">Duyệt</label>
                            <select class="form-control" id="exampleFormControlSelect1" name="tinhtrang">
                                <option value="1">Chấp nhận</option>
                                <option value="2">Không chấp nhận</option>
                            </select>
                        </div>

                        
                        <div class="form-group">
                            <input readonly type="hidden" class="form-control" id="exampleFormControlInput1" value=" <?php echo e($chitiet[0]->chinhsach_id); ?>" name="chinhsach_id">
                        </div>

                        
                        <?php if($chitiet[0]->tinhtrang == 0): ?>
                            <button type="submit" class="btn btn-primary">Xác nhận</button>
                        <?php else: ?>
                            <small class="text-danger d-block">Không thể duyệt lần 2</small>
                            <button disabled type="button" class="btn btn-primary">Tạm khóa duyệt</button>
                        <?php endif; ?>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\Modules/Admin\Resources/views/svchinhsach_detail/index.blade.php ENDPATH**/ ?>