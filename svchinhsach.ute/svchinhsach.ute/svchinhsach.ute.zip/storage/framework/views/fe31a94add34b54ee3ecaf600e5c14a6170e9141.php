

<?php $__env->startSection('chart'); ?>
    <script  src="https://www.gstatic.com/charts/loader.js"></script>
    <script >
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

            var data = google.visualization.arrayToDataTable([

            ['Task', 'Hours per Day'],
                <?php echo $chartData; ?>

            
            ]);

            var options = {
            title: 'Thống kê theo khoa'
            };
            var chart = new google.visualization.PieChart(document.getElementById('piechart'));
            chart.draw(data, options);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <h2>Thống kê</h2>
    <br />

    <div id="piechart" style="width: 900px; height: 500px;"></div>
    <hr>
    <h5>Số lượng sinh viên diện chính sách theo khoa:</h5>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Mã Khoa</th>
                <th>Tên khoa</th>
                <th>Số lượng</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $thongkekhoa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->k_ma); ?></td>
                    <td><?php echo e($item->k_ten); ?></td>
                    <td><?php echo e($item->soluong); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ctsv.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/ctsv/thongke.blade.php ENDPATH**/ ?>