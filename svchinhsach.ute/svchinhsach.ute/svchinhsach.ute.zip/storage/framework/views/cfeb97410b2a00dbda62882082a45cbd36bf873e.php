

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-xl-4">
            <div class="stats stats-primary">
                <h3 class="stats-title"> Tổng số lượt đăng ký </h3>
                <div class="stats-content">
                    
                    <div class="stats-data">
                        <div class="stats-number"><?php echo e($tongsvDK); ?></div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4">
            <div class="stats stats-success ">
                <h3 class="stats-title"> Chờ duyệt </h3>
                <div class="stats-content">
                    
                    <div class="stats-data">
                        <div class="stats-number"><?php echo e($chuaduyet); ?></div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4">
            <div class="stats stats-danger">
                <h3 class="stats-title"> Bị hủy </h3>
                <div class="stats-content">
                    
                    <div class="stats-data">
                        <div class="stats-number"><?php echo e($huy); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ctsv.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/ctsv/dashboard/dashboard.blade.php ENDPATH**/ ?>