


<?php $__env->startSection('content'); ?>
    <h2>Thống kê</h2>
    <br />

    <!-- Tab panes -->
    <div class="tab-content">
        <div id="home" class="container tab-pane active">
            <br />

            <h5>Số lượng sinh viên diện chính sách theo học kỳ</h5>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Học kỳ</th>
                        <th>Số lượng</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $thongkehocki; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->hk_ma); ?></td>
                            <td><?php echo e($item->soluong); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </tbody>
            </table>

        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ctsv.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/ctsv/thongke2.blade.php ENDPATH**/ ?>