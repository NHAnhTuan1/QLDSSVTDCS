

<?php $__env->startSection('content'); ?>
    <section class="list mt-5" style="margin-bottom: 60px">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="text-center">Thông tin cá nhân</h4>
                </div>
            </div>
            <form action="<?php echo e(route('sv.post.info')); ?>" method="POST">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="email">Họ và tên:</label>
                            <input readonly="" type="text" class="form-control" id="email" value="<?php echo e($sinhvien[0]->sv_ten); ?>">
                        </div>
                        <div class="form-group">
                            <label for="pwd">Lớp:</label>
                            <input readonly="" type="text" class="form-control" id="pwd" value="<?php echo e($sinhvien[0]->l_ten); ?>">
                        </div>
                        <div class="form-group">
                            <label for="pwd">Khoa:</label>
                            <input readonly="" type="text" class="form-control" id="pwd" value="<?php echo e($sinhvien[0]->k_ten); ?>">
                        </div>
                        <div class="form-group">
                            <label for="pwd">Địa chỉ:</label>
                            <input name="diachi" type="text" class="form-control" id="pwd" value="<?php echo e($sinhvien[0]->sv_diachi); ?>">
                            <?php $__errorArgs = ['diachi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="sel1">Giới tính:</label>
                        <select name="gioitinh" class="form-control" id="sel1" style="margin-bottom: 1rem">
                            <option value="1" <?php echo e(($sinhvien[0]->sv_gioitinh == 1)?'selected':''); ?>>Nam</option>
                            <option value="0" <?php echo e(($sinhvien[0]->sv_gioitinh == 0)?'selected':''); ?>>Nữ</option>
                        </select>
                        <div class="form-group">
                            <label for="pwd">Ngày sinh:</label>
                            <input name="ngaysinh" type="date" class="form-control" id="pwd" value="<?php echo e($sinhvien[0]->sv_ngaysinh); ?>">
                            <?php $__errorArgs = ['ngaysinh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="pwd">Số điện thoại:</label>
                            <input name="sdt" type="text" class="form-control" id="pwd" value="<?php echo e($sinhvien[0]->sv_sdt); ?>">
                            <?php $__errorArgs = ['sdt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="pwd">CMND:</label>
                            <input name="cmnd" type="text" class="form-control" id="pwd" value="<?php echo e($sinhvien[0]->sv_cmnd); ?>">
                            <?php $__errorArgs = ['cmnd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary">Lưu thông tin</button>
                    </div>
                </div>
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/sinhvien/info.blade.php ENDPATH**/ ?>