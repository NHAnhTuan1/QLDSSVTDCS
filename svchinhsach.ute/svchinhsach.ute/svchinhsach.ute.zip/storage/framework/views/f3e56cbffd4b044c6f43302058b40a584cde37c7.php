

<?php $__env->startSection('content'); ?>
    <section class="kq" style="min-height: 500px">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4>Kết quả tìm kiếm cho từ khóa: <?php echo e($tukhoa); ?></h4>
                </div>
            </div>
            <div class="row">

            <?php if($data->count() > 0): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                    <div class="thongbao d-flex">
                        <div class="date">
                            <p class="mb-0"><?php echo e(date('d', strtotime($tb->created_at))); ?></p>
                            <p class="mb-0"><?php echo e(date('m-Y', strtotime($tb->created_at))); ?></p>
                        </div>
                        <div class="info">
                            <a href=""><?php echo e($tb->tb_tieude); ?></a>
                        </div>
                    </div>
                    <hr>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-md-12">
                    <span class="text-danger">Không tìm thấy kết quả!</span>
                </div>
            <?php endif; ?>
            
                

                
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/timkiem/ketquathongbao.blade.php ENDPATH**/ ?>