

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 text-right">
            <a href="<?php echo e(route('ctsv.thongbao.create')); ?>">
                <button type="button" class="btn btn-success mb-1">Thêm mới</button>
            </a>
        </div>
        <div class="col-md-12">
            <div class="card spur-card">
                <div class="card-header">
                    <div class="spur-card-icon">
                        <i class="fas fa-table"></i>
                    </div>
                    <div class="spur-card-title">Quản lý thông báo</div>
                </div>
                <div class="card-body ">
                    <table class="table table-in-card">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Tiêu đề</th>
                                <th scope="col">Người đăng</th>
                                <th scope="col">Ngày tạo</th>
                                <th scope="col">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                        
                        <?php $__currentLoopData = $thongbao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($tb->id); ?></th>
                                <td style="max-width: 250px;"><?php echo e($tb->tb_tieude); ?></td>
                                <td><?php echo e($tb->ctsv_ten); ?></td>
                                <td><?php echo e(date('d/m/Y', strtotime($tb->created_at))); ?></td>
                                <td>
                                    <a href="" class="btn btn-warning">Sửa</a>
                                    <a href="" class="btn btn-danger">Xóa</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                            
                        </tbody>
                    </table>
                    <?php echo e($thongbao->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ctsv.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\resources\views/ctsv/thongbao.blade.php ENDPATH**/ ?>