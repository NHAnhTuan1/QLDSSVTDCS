

<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Sửa đối tượng</h4>
                    </div>
                    
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <?php if(Session::has('status')): ?>
                        <div class="alert alert-success"><?php echo e(Session::get('status')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <?php if(Session::has('err')): ?>
                        <div class="alert alert-danger"><?php echo e(Session::get('err')); ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-12">
                        <?php if(count($errors)>0): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($err); ?> <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-12">
                        <div class="card"> 
                            <div class="card-body">
                                <form class="form-horizontal form-material" action="<?php echo e(route('admin.doituong.update')); ?>" method="POST">
                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">ID</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input readonly type="text" class="form-control p-0 border-0" name="id" placeholder="Hộ nghèo" value="<?php echo e($doituong[0]->id); ?>"> 
                                        </div>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">Tên đối tượng</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input type="text" class="form-control p-0 border-0" name="ten" placeholder="Hộ nghèo" value="<?php echo e(old('ten', $doituong[0]->dt_ten)); ?>"> 
                                        </div>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">Hình thức miễn giảm(%)</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <input type="number" class="form-control p-0 border-0" name="hinhthuc" min="0" max="100" placeholder="30" value="<?php echo e(old('hinhthuc', $doituong[0]->dt_hinhthuc)); ?>"> 
                                        </div>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label class="col-md-12 p-0">Mô tả</label>
                                        <div class="col-md-12 border-bottom p-0">
                                            <textarea name="mota" rows="3" class="form-control p-0 border-0"><?php echo e(old('mota', $doituong[0]->dt_mota)); ?></textarea>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group mb-4">
                                        <div class="col-sm-12">
                                            <button type="submit" class="btn btn-success">Cập nhật</button>
                                        </div>
                                    </div>
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\svchinhsach.ute\Modules/Admin\Resources/views/doituong/edit.blade.php ENDPATH**/ ?>